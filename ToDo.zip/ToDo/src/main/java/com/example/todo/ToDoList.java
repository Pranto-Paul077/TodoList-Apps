package com.example.todo;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ToDoList extends Application {

    private ObservableList<Task> tasks = FXCollections.observableArrayList();

    @Override
    public void start(Stage primaryStage) throws Exception {
        GridPane root = new GridPane();
        root.setHgap(10);
        root.setVgap(10);
        root.setPadding(new Insets(10));

        // New task label and text field
        Label taskLabel = new Label("New Task:");
        root.add(taskLabel, 0, 0);

        TextField newItemTextField = new TextField();
        root.add(newItemTextField, 1, 0);

        // Add task button
        Button addButton = new Button("Add");
        addButton.setOnAction(e -> {
            String newTask = newItemTextField.getText();
            if (!newTask.isEmpty()) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                LocalDateTime now = LocalDateTime.now();
                tasks.add(new Task(dtf.format(now), newTask));
                newItemTextField.clear();
            }
        });
        root.add(addButton, 2, 0);

        // ListView for tasks
        ListView<Task> taskList = new ListView<>(tasks);
        taskList.setCellFactory(param -> new TaskListCell());
        taskList.setPrefHeight(100);
        root.add(taskList, 0, 1, 3, 1);

        // Remove task button
        Button removeButton = new Button("Remove");
        removeButton.setOnAction(e -> {
            Task selectedTask = taskList.getSelectionModel().getSelectedItem();
            if (selectedTask != null) {
                tasks.remove(selectedTask);
            }
        });

        // Initially, disable the "Remove" button
        removeButton.setDisable(true);
        root.add(removeButton, 2, 2);

        // Add a listener to enable/disable the "Remove" button based on selection
        taskList.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    // Enable the "Remove" button only when there's a valid selection
                    removeButton.setDisable(newValue == null);
                }
        );

        // Timer button
        Button timerButton = new Button("Start Timer");
        timerButton.setOnAction(e -> {
            Task selectedTask = taskList.getSelectionModel().getSelectedItem();
            if (selectedTask != null) {
                selectedTask.startTimer();
            }
        });
        root.add(timerButton, 2, 3);

        // Create and set the scene
        Scene scene = new Scene(root, 400, 300);
        primaryStage.setTitle("To-Do List");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Add a timer to update the task's elapsed time
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                Platform.runLater(() -> {
                    for (Task task : tasks) {
                        task.updateElapsedTime();
                    }
                    taskList.refresh();
                });
            }
        }).start();
    }

    public static void main(String[] args) {
        launch(args);
    }

    private static class Task {
        private LocalDateTime startTime;
        private String description;
        private int elapsedSeconds;
        private boolean isTimerRunning;

        public Task(String startTime, String description) {
            this.startTime = LocalDateTime.parse(startTime, DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));
            this.description = description;
            this.elapsedSeconds = 0;
            this.isTimerRunning = false;
        }

        public void startTimer() {
            isTimerRunning = true;
        }

        public void stopTimer() {
            isTimerRunning = false;
        }

        public void updateElapsedTime() {
            if (isTimerRunning) {
                LocalDateTime now = LocalDateTime.now();
                long secondsElapsed = java.time.Duration.between(startTime, now).getSeconds();
                elapsedSeconds = (int) secondsElapsed;
            }
        }

        public String getFormattedElapsedTime() {
            int hours = elapsedSeconds / 3600;
            int minutes = (elapsedSeconds % 3600) / 60;
            int seconds = elapsedSeconds % 60;
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        }

        @Override
        public String toString() {
            return String.format("%s - %s - Elapsed: %s", startTime.format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss")), description, getFormattedElapsedTime());
        }
    }

    private static class TaskListCell extends ListCell<Task> {
        @Override
        protected void updateItem(Task task, boolean empty) {
            super.updateItem(task, empty);

            if (empty || task == null) {
                setText(null);
            } else {
                setText(task.toString());
            }
        }
    }
}